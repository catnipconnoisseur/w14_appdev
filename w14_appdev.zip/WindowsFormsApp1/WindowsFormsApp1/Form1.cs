﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        MySqlConnection sqlConnect;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlDataAdapter;
        string query;
        DataTable dtTeamHome;
        DataTable dtTeamAway;
        DataTable dtTeamPick;
        DataTable dtMatch;
        DataTable dtPlayer;
        DataTable dtDate; 
        DataTable dtDatePick;
        DataTable dtDgv;
        string day = "";
        string month = "";
        string year = "";
        int goalHome = 0;
        int goalAway = 0;

        public Form1()
        { 
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                sqlConnect = new MySqlConnection("server=localhost;uid=student;pwd=isbmantap;database=premier_league");

                dtTeamHome = new DataTable();
                query = "SELECT * from team;";
                sqlCommand = new MySqlCommand(query, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                dtTeamHome = new DataTable();
                sqlDataAdapter.Fill(dtTeamHome);

                cb_teamHome.DataSource = dtTeamHome;
                cb_teamHome.DisplayMember = "team_name";
                cb_teamHome.ValueMember = "team_id";
                cb_teamHome.Text = "";

                dtTeamAway = new DataTable();
                query = "SELECT * from team;";
                sqlCommand = new MySqlCommand(query, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                dtTeamHome = new DataTable();
                sqlDataAdapter.Fill(dtTeamAway);

                cb_teamAway.DataSource = dtTeamAway;
                cb_teamAway.DisplayMember = "team_name";
                cb_teamAway.ValueMember = "team_id";
                cb_teamAway.Text = "";

                dtDgv = new DataTable();
                dtDgv.Columns.Add("Team");
                dtDgv.Columns.Add("Player");
                dtDgv.Columns.Add("Type");
                dgv_view.DataSource = dtDgv;

                dtMatch = new DataTable();
                dtMatch.Columns.Add("minute");
                dtMatch.Columns.Add("team_id");
                dtMatch.Columns.Add("player_id");
                dtMatch.Columns.Add("type");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void cb_teamHome_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (cb_teamAway.Text == cb_teamHome.Text)
                {
                    MessageBox.Show("Error, tim tidak boleh sama");
                }
                else
                {
                    dtTeamPick = new DataTable();
                    query = $@"SELECT team_name, team_id FROM team WHERE team_id = '{cb_teamAway.SelectedValue}' OR team_id = '{cb_teamHome.SelectedValue}';";

                    sqlCommand = new MySqlCommand(query, sqlConnect);
                    sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                    sqlDataAdapter.Fill(dtTeamPick);

                    cb_team.DataSource = dtTeamPick;
                    cb_team.DisplayMember = "team_name";
                    cb_team.ValueMember = "team_id";
                    cb_team.Text = "";
                    cb_type.Text = "";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void cb_teamAway_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (cb_teamAway.Text == cb_teamHome.Text)
                {
                    MessageBox.Show("Error, tim tidak boleh sama");
                }
                else
                {
                    dtTeamPick = new DataTable();
                    query = $@"SELECT team_name, team_id FROM teamnWHERE team_id = '{cb_teamAway.SelectedValue}' OR team_id = '{cb_teamHome.SelectedValue}';";

                    sqlCommand = new MySqlCommand(query, sqlConnect);
                    sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                    sqlDataAdapter.Fill(dtTeamPick);

                    cb_team.DataSource = dtTeamPick;
                    cb_team.DisplayMember = "team_name";
                    cb_team.ValueMember = "team_id";
                    cb_team.Text = "";
                    cb_type.Text = "";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void cb_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                dtPlayer = new DataTable();
                query = $@"SELECT player_name, player_id FROM player p WHERE team_id = '{cb_team.SelectedValue}';";

                sqlCommand = new MySqlCommand(query, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(dtPlayer);

                cb_player.DataSource = dtPlayer;
                cb_player.DisplayMember = "player_name";
                cb_player.ValueMember = "player_id";
                cb_player.Text = "";

                cb_type.Text = "";

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            if (tb_minute.Text == "" || cb_team.Text == "" || cb_player.Text == "" || cb_type.Text == "" || tb_matchID.Text == "")
            {
                MessageBox.Show("Error, lengkapi data");
            }
            else
            {
                dtDgv.Rows.Add(cb_team.Text, cb_player.Text, cb_type.Text);

                if (cb_type.Text == "GO" || cb_type.Text == "GP")
                {
                    if (cb_teamAway.Text == cb_team.Text)
                    {
                        goalAway++;
                    }
                    else
                    {
                        goalHome++;
                    }
                }
                else if (cb_type.Text == "GW")
                {
                    if (cb_teamAway.Text == cb_team.Text)
                    {
                        goalHome++;
                    }
                    else
                    {
                        goalAway++;
                    }
                }

                dtMatch.Rows.Add(tb_minute.Text, cb_team.SelectedValue, cb_player.SelectedValue, cb_type.Text);
                cb_type.Text = "";
                tb_minute.Clear();
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            DataGridViewRow view = dgv_view.CurrentRow;
            int indexRemove = 0;

            if (dgv_view.Rows.Count != 0)
            {
                for (int i = 0; i < dtDgv.Rows.Count; i++)
                {
                    if (dtDgv.Rows[i][0].ToString().Contains(view.Cells[0].Value.ToString()))
                    {
                        indexRemove = i;
                    }

                }
                if (view.Cells[2].Value.ToString() == "GO" || view.Cells[2].Value.ToString() == "GP")
                {
                    if (cb_teamAway.Text == cb_team.Text)
                    {
                        goalAway--;
                    }
                    else
                    {
                        goalHome--;
                    }
                }
                else if (view.Cells[2].Value.ToString() == "GW")
                {
                    if (cb_teamAway.Text == cb_team.Text)
                    {
                        goalHome--;
                    }
                    else
                    {
                        goalAway--;
                    }
                }
                dtDgv.Rows.RemoveAt(indexRemove);
                dtMatch.Rows.RemoveAt(indexRemove);
            }
            dgv_view.DataSource = dtDgv;
        }

        private void btn_insert_Click(object sender, EventArgs e)
        {
            try
            {
                if (tb_matchID.Text != "")
                {
                    for (int i = 0; i < dgv_view.Rows.Count; i++)
                    {
                        query = $@"INSERT INTO DMatch VALUES ('{tb_matchID.Text}', '{dtMatch.Rows[i][0].ToString()}', '{dtMatch.Rows[i][1].ToString()}', '{dtMatch.Rows[i][2].ToString()}', '{dtMatch.Rows[i][3].ToString()}', '0');";

                        sqlConnect.Open();
                        sqlCommand = new MySqlCommand(query, sqlConnect);
                        sqlCommand.ExecuteNonQuery();
                        sqlConnect.Close();
                    }

                    query = $@"INSERT INTO `match` VALUES ('{tb_matchID.Text}', '{year}-{month}-{day}', '{cb_teamHome.SelectedValue}', '{cb_teamAway.SelectedValue}', '{goalHome.ToString()}', '{goalAway.ToString()}', 'M002', '0');";

                    sqlConnect.Open();
                    sqlCommand = new MySqlCommand(query, sqlConnect);
                    sqlCommand.ExecuteNonQuery();
                    sqlConnect.Close();

                    cb_teamAway.Text = "";
                    cb_teamHome.Text = "";
                    tb_minute.Text = "";
                    cb_type.Text = "";
                    cb_team.Text = "";
                    cb_player.Text = "";
                    tb_matchID.Text = "";

                    dtDgv.Rows.Clear();
                    dtMatch.Rows.Clear();
                    goalAway = 0;
                    goalHome = 0;
                }
                else
                {
                    MessageBox.Show("Error, lengkapi data");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void dtp_matchDate_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                query = $@"SELECT concat(date_format(match_date, '%Y'), date_format(match_date, '%m'), date_format(match_Date, '%d')) FROM `match` ORDER BY 1 desc LIMIT 1;";
                sqlCommand = new MySqlCommand(query, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                dtDate = new DataTable();
                sqlDataAdapter.Fill(dtDate);

                day = dtp_matchDate.Value.Day.ToString();
                if (Convert.ToInt32(day) < 10)
                {
                    day = $"0{day}";
                }

                month = dtp_matchDate.Value.Month.ToString();
                if (Convert.ToInt32(month) < 10)
                {
                    month = $"0{month}";
                }

                year = dtp_matchDate.Value.Year.ToString();

                int dateChoose = Convert.ToInt32($"{year}{month}{day}");
                int dateLast = Convert.ToInt32(dtDate.Rows[0][0]);

                if (dateChoose >= Convert.ToInt32(dtDate.Rows[0][0]))
                {
                    query = $@"SELECT match_id FROM `match` WHERE match_id like '{year}%' ORDER BY 1 desc LIMIT 1;";

                    sqlCommand = new MySqlCommand(query, sqlConnect);
                    sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                    dtDatePick = new DataTable();
                    sqlDataAdapter.Fill(dtDatePick);

                    if (dtDatePick.Rows.Count == 0)
                    {
                        tb_matchID.Text = $"{year}001";
                    }
                    else if (dtDatePick.Rows.Count == 1)
                    {
                        int jumlahMatch = Convert.ToInt32(dtDatePick.Rows[0][0]) + 1;
                        tb_matchID.Text = $"{jumlahMatch}";
                    }
                }
                else
                {
                    MessageBox.Show("Error, pilih tanggal setelah tanggal match sebelumnya");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
