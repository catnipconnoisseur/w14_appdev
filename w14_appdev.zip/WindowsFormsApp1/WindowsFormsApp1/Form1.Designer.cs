﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_matchID = new System.Windows.Forms.Label();
            this.lb_teamHome = new System.Windows.Forms.Label();
            this.lb_matchDate = new System.Windows.Forms.Label();
            this.lb_teamAway = new System.Windows.Forms.Label();
            this.tb_matchID = new System.Windows.Forms.TextBox();
            this.dtp_matchDate = new System.Windows.Forms.DateTimePicker();
            this.cb_teamHome = new System.Windows.Forms.ComboBox();
            this.cb_teamAway = new System.Windows.Forms.ComboBox();
            this.dgv_view = new System.Windows.Forms.DataGridView();
            this.lb_minute = new System.Windows.Forms.Label();
            this.lb_team = new System.Windows.Forms.Label();
            this.lb_player = new System.Windows.Forms.Label();
            this.lb_type = new System.Windows.Forms.Label();
            this.tb_minute = new System.Windows.Forms.TextBox();
            this.cb_team = new System.Windows.Forms.ComboBox();
            this.cb_player = new System.Windows.Forms.ComboBox();
            this.cb_type = new System.Windows.Forms.ComboBox();
            this.btn_add = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_insert = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_view)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_matchID
            // 
            this.lb_matchID.AutoSize = true;
            this.lb_matchID.Location = new System.Drawing.Point(56, 67);
            this.lb_matchID.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_matchID.Name = "lb_matchID";
            this.lb_matchID.Size = new System.Drawing.Size(74, 20);
            this.lb_matchID.TabIndex = 0;
            this.lb_matchID.Text = "Match ID";
            // 
            // lb_teamHome
            // 
            this.lb_teamHome.AutoSize = true;
            this.lb_teamHome.Location = new System.Drawing.Point(56, 114);
            this.lb_teamHome.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_teamHome.Name = "lb_teamHome";
            this.lb_teamHome.Size = new System.Drawing.Size(96, 20);
            this.lb_teamHome.TabIndex = 1;
            this.lb_teamHome.Text = "Team Home";
            // 
            // lb_matchDate
            // 
            this.lb_matchDate.AutoSize = true;
            this.lb_matchDate.Location = new System.Drawing.Point(461, 67);
            this.lb_matchDate.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_matchDate.Name = "lb_matchDate";
            this.lb_matchDate.Size = new System.Drawing.Size(92, 20);
            this.lb_matchDate.TabIndex = 2;
            this.lb_matchDate.Text = "Match Date";
            // 
            // lb_teamAway
            // 
            this.lb_teamAway.AutoSize = true;
            this.lb_teamAway.Location = new System.Drawing.Point(461, 114);
            this.lb_teamAway.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_teamAway.Name = "lb_teamAway";
            this.lb_teamAway.Size = new System.Drawing.Size(91, 20);
            this.lb_teamAway.TabIndex = 3;
            this.lb_teamAway.Text = "Team Away";
            // 
            // tb_matchID
            // 
            this.tb_matchID.Enabled = false;
            this.tb_matchID.Location = new System.Drawing.Point(178, 65);
            this.tb_matchID.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tb_matchID.Name = "tb_matchID";
            this.tb_matchID.Size = new System.Drawing.Size(168, 26);
            this.tb_matchID.TabIndex = 4;
            // 
            // dtp_matchDate
            // 
            this.dtp_matchDate.Location = new System.Drawing.Point(598, 63);
            this.dtp_matchDate.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dtp_matchDate.Name = "dtp_matchDate";
            this.dtp_matchDate.Size = new System.Drawing.Size(280, 26);
            this.dtp_matchDate.TabIndex = 5;
            this.dtp_matchDate.ValueChanged += new System.EventHandler(this.dtp_matchDate_ValueChanged);
            // 
            // cb_teamHome
            // 
            this.cb_teamHome.FormattingEnabled = true;
            this.cb_teamHome.Location = new System.Drawing.Point(178, 111);
            this.cb_teamHome.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cb_teamHome.Name = "cb_teamHome";
            this.cb_teamHome.Size = new System.Drawing.Size(168, 28);
            this.cb_teamHome.TabIndex = 6;
            this.cb_teamHome.SelectedIndexChanged += new System.EventHandler(this.cb_teamHome_SelectedIndexChanged);
            // 
            // cb_teamAway
            // 
            this.cb_teamAway.FormattingEnabled = true;
            this.cb_teamAway.Location = new System.Drawing.Point(598, 111);
            this.cb_teamAway.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cb_teamAway.Name = "cb_teamAway";
            this.cb_teamAway.Size = new System.Drawing.Size(168, 28);
            this.cb_teamAway.TabIndex = 7;
            this.cb_teamAway.SelectedIndexChanged += new System.EventHandler(this.cb_teamAway_SelectedIndexChanged);
            // 
            // dgv_view
            // 
            this.dgv_view.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_view.Location = new System.Drawing.Point(60, 195);
            this.dgv_view.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dgv_view.Name = "dgv_view";
            this.dgv_view.RowHeadersWidth = 82;
            this.dgv_view.RowTemplate.Height = 33;
            this.dgv_view.Size = new System.Drawing.Size(706, 318);
            this.dgv_view.TabIndex = 8;
            // 
            // lb_minute
            // 
            this.lb_minute.AutoSize = true;
            this.lb_minute.Location = new System.Drawing.Point(832, 198);
            this.lb_minute.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_minute.Name = "lb_minute";
            this.lb_minute.Size = new System.Drawing.Size(57, 20);
            this.lb_minute.TabIndex = 9;
            this.lb_minute.Text = "Minute";
            // 
            // lb_team
            // 
            this.lb_team.AutoSize = true;
            this.lb_team.Location = new System.Drawing.Point(832, 242);
            this.lb_team.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_team.Name = "lb_team";
            this.lb_team.Size = new System.Drawing.Size(49, 20);
            this.lb_team.TabIndex = 10;
            this.lb_team.Text = "Team";
            // 
            // lb_player
            // 
            this.lb_player.AutoSize = true;
            this.lb_player.Location = new System.Drawing.Point(832, 290);
            this.lb_player.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_player.Name = "lb_player";
            this.lb_player.Size = new System.Drawing.Size(52, 20);
            this.lb_player.TabIndex = 11;
            this.lb_player.Text = "Player";
            // 
            // lb_type
            // 
            this.lb_type.AutoSize = true;
            this.lb_type.Location = new System.Drawing.Point(832, 340);
            this.lb_type.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_type.Name = "lb_type";
            this.lb_type.Size = new System.Drawing.Size(43, 20);
            this.lb_type.TabIndex = 12;
            this.lb_type.Text = "Type";
            // 
            // tb_minute
            // 
            this.tb_minute.Location = new System.Drawing.Point(915, 195);
            this.tb_minute.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tb_minute.Name = "tb_minute";
            this.tb_minute.Size = new System.Drawing.Size(168, 26);
            this.tb_minute.TabIndex = 13;
            // 
            // cb_team
            // 
            this.cb_team.FormattingEnabled = true;
            this.cb_team.Location = new System.Drawing.Point(915, 240);
            this.cb_team.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cb_team.Name = "cb_team";
            this.cb_team.Size = new System.Drawing.Size(168, 28);
            this.cb_team.TabIndex = 14;
            this.cb_team.SelectedIndexChanged += new System.EventHandler(this.cb_team_SelectedIndexChanged);
            // 
            // cb_player
            // 
            this.cb_player.FormattingEnabled = true;
            this.cb_player.Location = new System.Drawing.Point(915, 288);
            this.cb_player.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cb_player.Name = "cb_player";
            this.cb_player.Size = new System.Drawing.Size(168, 28);
            this.cb_player.TabIndex = 15;
            // 
            // cb_type
            // 
            this.cb_type.FormattingEnabled = true;
            this.cb_type.Location = new System.Drawing.Point(915, 338);
            this.cb_type.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cb_type.Name = "cb_type";
            this.cb_type.Size = new System.Drawing.Size(168, 28);
            this.cb_type.TabIndex = 16;
            // 
            // btn_add
            // 
            this.btn_add.Location = new System.Drawing.Point(844, 409);
            this.btn_add.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(104, 34);
            this.btn_add.TabIndex = 17;
            this.btn_add.Text = "Add";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(968, 409);
            this.btn_delete.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(104, 34);
            this.btn_delete.TabIndex = 18;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // btn_insert
            // 
            this.btn_insert.Location = new System.Drawing.Point(844, 479);
            this.btn_insert.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_insert.Name = "btn_insert";
            this.btn_insert.Size = new System.Drawing.Size(228, 34);
            this.btn_insert.TabIndex = 19;
            this.btn_insert.Text = "Insert";
            this.btn_insert.UseVisualStyleBackColor = true;
            this.btn_insert.Click += new System.EventHandler(this.btn_insert_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1150, 576);
            this.Controls.Add(this.btn_insert);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.cb_type);
            this.Controls.Add(this.cb_player);
            this.Controls.Add(this.cb_team);
            this.Controls.Add(this.tb_minute);
            this.Controls.Add(this.lb_type);
            this.Controls.Add(this.lb_player);
            this.Controls.Add(this.lb_team);
            this.Controls.Add(this.lb_minute);
            this.Controls.Add(this.dgv_view);
            this.Controls.Add(this.cb_teamAway);
            this.Controls.Add(this.cb_teamHome);
            this.Controls.Add(this.dtp_matchDate);
            this.Controls.Add(this.tb_matchID);
            this.Controls.Add(this.lb_teamAway);
            this.Controls.Add(this.lb_matchDate);
            this.Controls.Add(this.lb_teamHome);
            this.Controls.Add(this.lb_matchID);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form1";
            this.Text = "Insert Match";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_view)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_matchID;
        private System.Windows.Forms.Label lb_teamHome;
        private System.Windows.Forms.Label lb_matchDate;
        private System.Windows.Forms.Label lb_teamAway;
        private System.Windows.Forms.TextBox tb_matchID;
        private System.Windows.Forms.DateTimePicker dtp_matchDate;
        private System.Windows.Forms.ComboBox cb_teamHome;
        private System.Windows.Forms.ComboBox cb_teamAway;
        private System.Windows.Forms.DataGridView dgv_view;
        private System.Windows.Forms.Label lb_minute;
        private System.Windows.Forms.Label lb_team;
        private System.Windows.Forms.Label lb_player;
        private System.Windows.Forms.Label lb_type;
        private System.Windows.Forms.TextBox tb_minute;
        private System.Windows.Forms.ComboBox cb_team;
        private System.Windows.Forms.ComboBox cb_player;
        private System.Windows.Forms.ComboBox cb_type;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Button btn_insert;
    }
}

